#ifndef COMMON_H
#define COMMON_H

#include "device.h"

/***********************************************************************
 * ------------------------ Timer settings -----------------------------
 **********************************************************************/
#define _10MHZ	63320
#define _16MHZ	61768
#define _20MHZ	60768
#define _32MHZ	57768
#define _40MHZ 	55768

/***********************************************************************
 * ----------------------------- Events --------------------------------
 **********************************************************************/
#define ALARM_EVENT       0x80
#define LCD_EVENT

/***********************************************************************
 * ----------------------------- Task ID -------------------------------
 **********************************************************************/
/* Info about the tasks:
 * TASK0: USART
 * TASK1: USART
 */
#define RCV_ID        1
#define LCD_ID        2
#define GAME_ID       3
#define RCV_SENT_ID   4

/* Priorities of the tasks */

#define RCV_TASK_PRIO           8
#define LCD_TASK_PRIO           9
#define GAME_TASK_PRIO          10
#define RCV_SENT_TASK_PRIO      11


#define RCV_ALARM           0
#define LCD_ALARM           1
#define GAME_ALARM          2
#define RCV_SENT_ALARM      3

#define ALARM_TSK0          0

#endif

/* End of File : common.h */
